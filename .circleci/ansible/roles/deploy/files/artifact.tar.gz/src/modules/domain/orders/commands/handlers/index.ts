import { OrderCreator } from './orderCreator';

export const CommandHandlers = [OrderCreator];
